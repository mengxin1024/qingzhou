package com.yupi.yupao.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yupi.yupao.model.domain.UserTeam;

/**
 * 用户队伍服务
 *
 */
public interface UserTeamService extends IService<UserTeam> {

}
