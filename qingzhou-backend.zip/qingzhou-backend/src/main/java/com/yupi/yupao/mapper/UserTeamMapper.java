package com.yupi.yupao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yupi.yupao.model.domain.UserTeam;

/**
 * 用户队伍 Mapper
 *
 */
public interface UserTeamMapper extends BaseMapper<UserTeam> {

}




